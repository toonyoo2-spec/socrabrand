# [작업지침] 12. 영어 싫다는 아이, 억지로 시키기 전에 확인할 것

> 이 파일은 **작업지침 → 이미지 프롬프트 → 본문** 순서로 되어 있어요. 에디터에는 맨 아래 `▼ 본문 시작` 줄 **다음부터** 붙여 넣어 주세요.

## 1. 게시 정보

| 항목 | 내용 |
|---|---|
| 영역 | 새로운 이야기 |
| 카테고리 | 아티클 |
| 태그 | 부모 가이드 |
| 날짜/표기 | 2026.09.12 · 5분 읽기 |
| 카드 요약문 | 흥미를 잃은 이유부터 살펴보면 다시 시작할 방법이 보여요. |
| 카드·이미지 기준 색 | very pale mint (#E8F7EC) |
| 사이트 카드 수정 | 없음 (카드 문구 그대로) |

## 2. 이미지 작업 목록 (총 5장)

| # | 파일명 | 용도 | 비율 | 넣을 위치 | 캡션 |
|---|---|---|---|---|---|
| 0 | 12-hero.png | 대표(썸네일) | 16:9 | 게시글 대표 이미지 칸 (본문에 넣지 않음) | 영어 싫다는 아이, 먼저 확인할 것 |
| 1 | 12-1.png | 본문 (M) | 3:2 | `'싫다'는 말 뒤에 숨은 진짜 마음` 섹션 첫 문단 바로 아래 (`IMAGE-URL-12-1` 자리) | '싫어' 한마디에 담긴 여러 가지 마음 |
| 2 | 12-2.png | 본문 (M) | 3:2 | `억지로 시키기 전에 확인할 다섯 가지` 섹션 제목 바로 아래(첫 소제목보다 위) (`IMAGE-URL-12-2` 자리) | 억지로 시키기 전에 살펴볼 다섯 가지 |
| 3 | 12-3.png | 본문 (M) | 3:2 | `다시 시작하는 작은 방법들` 섹션 첫 문단 바로 아래 (`IMAGE-URL-12-3` 자리) | 쉬운 책, 좋아하는 주제로 다시 시작해요 |
| 4 | 12-4.png | 본문 (M) | 3:2 | `부모님의 마음도 챙겨 주세요` 섹션 첫 문단 바로 아래 (`IMAGE-URL-12-4` 자리) | 조급한 마음을 내려놓고 아이의 속도에 맞춰요 |

## 3. 영문 프롬프트

### 대표 이미지 — 12-hero.png (16:9)

```
A child sitting with arms crossed and a pouting face beside an English workbook, while a parent kneels next to them with an open, caring expression. Soft flat editorial illustration with subtle paper grain, rounded friendly shapes, warm natural light, calm and hopeful mood, limited pastel palette dominated by very pale mint (#E8F7EC), clean composition with generous negative space. People are Korean elementary school children and parents with simple, friendly faces. Original artwork, not imitating any existing book or brand. No text, no letters, no numbers, no logos, no watermarks. Horizontal 16:9 composition.
```

### 본문 이미지 1 — 12-1.png (3:2)
- 위치: `'싫다'는 말 뒤에 숨은 진짜 마음` 섹션 첫 문단 바로 아래
- 캡션: '싫어' 한마디에 담긴 여러 가지 마음

```
A large speech bubble gently opening to reveal smaller bubbles inside, each with an icon: a tired face, a worried face, a bored face and a steep mountain. Soft flat editorial illustration with subtle paper grain, rounded friendly shapes, warm natural light, calm and hopeful mood, limited pastel palette dominated by very pale mint (#E8F7EC), clean composition with generous negative space. People are Korean elementary school children and parents with simple, friendly faces. Original artwork, not imitating any existing book or brand. No text, no letters, no numbers, no logos, no watermarks. Horizontal 3:2 composition.
```

### 본문 이미지 2 — 12-2.png (3:2)
- 위치: `억지로 시키기 전에 확인할 다섯 가지` 섹션 제목 바로 아래(첫 소제목보다 위)
- 캡션: 억지로 시키기 전에 살펴볼 다섯 가지

```
A parent holding a magnifying glass up to a board with five icon items: a staircase, a broken star, a heavy backpack, a dinosaur and a clock. Soft flat editorial illustration with subtle paper grain, rounded friendly shapes, warm natural light, calm and hopeful mood, limited pastel palette dominated by very pale mint (#E8F7EC), clean composition with generous negative space. People are Korean elementary school children and parents with simple, friendly faces. Original artwork, not imitating any existing book or brand. No text, no letters, no numbers, no logos, no watermarks. Horizontal 3:2 composition.
```

### 본문 이미지 3 — 12-3.png (3:2)
- 위치: `다시 시작하는 작은 방법들` 섹션 첫 문단 바로 아래
- 캡션: 쉬운 책, 좋아하는 주제로 다시 시작해요

```
A child happily reading an easy picture book about dinosaurs, sitting on stepping stones that lead gently upward. Soft flat editorial illustration with subtle paper grain, rounded friendly shapes, warm natural light, calm and hopeful mood, limited pastel palette dominated by very pale mint (#E8F7EC), clean composition with generous negative space. People are Korean elementary school children and parents with simple, friendly faces. Original artwork, not imitating any existing book or brand. No text, no letters, no numbers, no logos, no watermarks. Horizontal 3:2 composition.
```

### 본문 이미지 4 — 12-4.png (3:2)
- 위치: `부모님의 마음도 챙겨 주세요` 섹션 첫 문단 바로 아래
- 캡션: 조급한 마음을 내려놓고 아이의 속도에 맞춰요

```
A parent sitting calmly with a cup of tea, watching the child play in soft late-afternoon light, peaceful atmosphere. Soft flat editorial illustration with subtle paper grain, rounded friendly shapes, warm natural light, calm and hopeful mood, limited pastel palette dominated by very pale mint (#E8F7EC), clean composition with generous negative space. People are Korean elementary school children and parents with simple, friendly faces. Original artwork, not imitating any existing book or brand. No text, no letters, no numbers, no logos, no watermarks. Horizontal 3:2 composition.
```

## 4. 작업 순서

1. 위 프롬프트로 이미지 5장을 생성해요. 비율은 표대로 맞추고, 글자가 생긴 컷은 다시 생성해요.
2. 이미지를 업로드해서 URL을 받아요.
3. 본문의 `IMAGE-URL-12-1` ~ `IMAGE-URL-12-4`를 업로드한 URL로 바꿔요.
4. `12-hero.png`는 게시글 대표 이미지(썸네일) 칸에 등록해요.
5. 미리보기로 이미지 위치와 캡션을 확인한 뒤 발행해요.

▼ 본문 시작 (이 줄 아래부터 에디터에 붙여넣기) ▼

# 영어 싫다는 아이, 억지로 시키기 전에 확인할 것

"영어 하기 싫어!" 이 한마디에 마음이 철렁하셨던 적 있으시죠? 그동안 들인 시간과 노력을 생각하면 "그래도 해야지"라는 말이 먼저 나오기 쉬워요. 하지만 억지로 책상 앞에 앉히기 전에, 잠깐 멈춰서 살펴봐야 할 것들이 있어요. 아이가 영어를 싫어하게 된 데에는 대부분 이유가 있고, 그 이유를 찾으면 다시 시작할 방법도 보이거든요.

## '싫다'는 말 뒤에 숨은 진짜 마음

아이가 "싫어"라고 말할 때, 그 말이 꼭 영어 자체를 싫어한다는 뜻은 아니에요. 아이들은 복잡한 감정을 정확하게 설명하기 어려워서, 여러 가지 마음을 "싫어" 한마디에 담곤 해요.

![M:'싫어' 한마디에 담긴 여러 가지 마음](IMAGE-URL-12-1)

-- "너무 어려워서 못 하겠어"
-- "틀릴까 봐 무서워"
-- "재미가 없어"
-- "지금 너무 피곤해"
-- "다른 걸 하고 싶어"

같은 "싫어"라도 이유가 다르면 해결 방법도 달라요. 그래서 먼저 아이의 마음을 들여다보는 시간이 필요해요.

> 아이의 "싫어"는 마침표가 아니라 물음표예요.

---

## 억지로 시키기 전에 확인할 다섯 가지

![M:억지로 시키기 전에 살펴볼 다섯 가지](IMAGE-URL-12-2)

**1. 난이도가 맞나요?**
아이 수준보다 너무 어려운 학습은 영어를 싫어하게 만드는 흔한 원인 중 하나예요. 문장의 대부분을 이해하지 못하면 아이는 금방 지치고 흥미를 잃어요. 최근에 교재나 반이 바뀌었다면, 그 변화가 아이에게 너무 큰 도약은 아니었는지 살펴봐 주세요.

**2. 실패 경험이 쌓였나요?**
틀린 답을 자주 지적받거나, 친구 앞에서 실수한 경험이 반복되면 아이는 영어를 '내가 못하는 것'으로 기억해요. 언어학자 스티븐 크라센(Stephen Krashen)은 불안이나 긴장 같은 정서가 언어 습득을 방해할 수 있다는 '정의적 여과(affective filter)' 가설을 제시했어요. 마음이 불편하면 아무리 좋은 학습도 잘 들어가지 않는다는 뜻이에요.

**3. 학습량이 너무 많지 않나요?**
학원, 숙제, 단어 시험까지 영어와 관련된 일정이 하루를 가득 채우고 있다면, 아이는 영어를 '끝나지 않는 숙제'로 느낄 수 있어요. 일주일 일정표를 펼쳐 놓고 아이가 쉴 수 있는 시간이 충분한지 확인해 보세요.

**4. 아이의 관심사와 연결되어 있나요?**
공룡을 좋아하는 아이에게 쇼핑 대화문만 반복하면 흥미가 생기기 어려워요. 아이가 좋아하는 주제와 영어가 만나는 지점이 있는지 살펴보세요.

**5. 영어 외의 이유는 없나요?**
가끔은 영어가 아니라 다른 것이 문제일 때도 있어요. 수업 시간대가 아이의 컨디션과 맞지 않거나, 함께 수업하는 친구 관계에 어려움이 있을 수도 있어요. 아이와 편안하게 이야기 나누며 영어 시간 전후의 상황을 함께 살펴봐 주세요.

---

## 아이와 대화를 시작하는 질문

이유를 찾으려면 아이의 이야기를 들어야 해요. 다그치는 대신 이렇게 물어봐 주세요.

== "영어 할 때 제일 힘든 게 뭐야?"
== "영어 시간에 그래도 좀 괜찮았던 순간은 언제야?"
== "영어로 해 보고 싶은 게 있다면 뭐야?"

아이가 대답하지 않거나 "몰라"라고 해도 괜찮아요. 며칠 뒤 다시 가볍게 물어봐 주세요. 대화의 문을 열어 두는 것만으로도 아이는 '내 마음을 알아주려는 사람'이 있다고 느껴요.

## 다시 시작하는 작은 방법들

이유를 찾았다면, 그에 맞게 작은 것부터 바꿔 보세요.

![M:쉬운 책, 좋아하는 주제로 다시 시작해요](IMAGE-URL-12-3)

-- **난이도 낮추기**: 아이가 술술 읽을 수 있는 쉬운 책으로 잠시 돌아가요. 성공 경험이 다시 자신감을 만들어요.
-- **양 줄이기**: 하루 30분이던 영어 시간을 10분으로 줄여도 괜찮아요. 끊기지 않는 것이 더 중요해요.
-- **관심사로 시작하기**: 좋아하는 캐릭터, 게임, 스포츠와 관련된 영어 영상이나 책을 함께 찾아보세요.
-- **선택권 주기**: "오늘은 그림책 읽을래, 영상 볼래?"처럼 아이가 고를 수 있게 해 주세요. 스스로 고른 활동에는 더 오래 머물러요.
-- **함께하기**: 부모님이 먼저 영어를 즐기는 모습을 보여주세요. 영어 노래를 흥얼거리는 것만으로도 충분해요.

::: callout
**잠시 쉬어도 괜찮아요**
아이가 많이 지쳐 있다면, 영어를 잠깐 쉬는 것도 방법이에요. 이때도 완전히 끊기보다는 좋아하는 영어 노래나 영상처럼 부담 없는 접촉은 이어가는 걸 추천해요. 쉬는 시간이 다시 시작할 힘이 되기도 해요.
:::

## 상황별 대응 예시

**숙제 앞에서 울음을 터뜨린다면**
그 자리에서 숙제를 끝내게 하기보다, 먼저 감정을 진정시켜 주세요. "많이 힘들었구나. 어디까지 해 볼까?"처럼 아이가 할 수 있는 만큼을 함께 정하면 다시 연필을 들 힘이 생겨요.

**수업에 가기 싫다고 한다면**
수업 내용이 어려운지, 선생님이나 친구와의 관계가 불편한지 구분해 보세요. 필요하다면 담당 선생님과 상담해 아이가 수업에서 어떤 모습인지 확인하는 것도 좋아요.

**영어책만 펼치면 딴짓을 한다면**
책의 수준과 주제를 점검해 보세요. 아이가 서점이나 도서관에서 직접 고른 책에는 더 오래 머무는 경우가 많아요.

**이럴 땐 상담을 받아 보세요**
영어뿐 아니라 다른 과목이나 학교생활 전반에서 거부감이 크고, 그 상태가 오래 이어진다면 학습 문제만이 아닐 수 있어요. 담임선생님이나 전문 상담 기관과 이야기 나눠 보는 것을 권해요.

## 부모님의 마음도 챙겨 주세요

아이가 영어를 싫어한다고 하면 부모님도 실망하고 불안해지기 쉬워요. 그 마음이 아이에게 그대로 전해지면, 아이는 영어 시간을 더 무겁게 느끼게 돼요. 지금의 거부감은 영원한 상태가 아니라 지나가는 한 시기일 수 있어요. 조급한 마음을 잠시 내려놓고, 아이의 속도에 맞춰 함께 걸어가 주세요.

![M:조급한 마음을 내려놓고 아이의 속도에 맞춰요](IMAGE-URL-12-4)

## 억지로 한 영어는 오래가지 않아요

영어는 짧게 끝나는 과목이 아니라 오랜 시간 함께 갈 언어예요. 지금 억지로 몇 페이지를 더 시키는 것보다, 아이가 다시 영어를 '해 볼 만한 것'으로 느끼게 만드는 것이 훨씬 멀리 가는 길이에요.

영어를 좋아하는 마음은 한 번 꺾였다고 사라지지 않아요. 아이에게 맞는 속도와 방법을 찾으면, 다시 영어 노래를 흥얼거리고 영어 영상을 먼저 찾아보는 날이 와요. 그날까지 부모님이 해 줄 수 있는 가장 큰 일은 기다려 주는 것이에요.

오늘 아이가 "영어 싫어"라고 말한다면, 혼내기 전에 한 번만 물어봐 주세요. "어떤 게 제일 힘들었어?" 그 질문에서 다시 시작할 방법이 보일 거예요.
