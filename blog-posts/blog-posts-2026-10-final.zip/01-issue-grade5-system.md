# [작업지침] 01. 내신 5등급제 전환, 초등 학부모가 알아둘 3가지

> 이 파일은 **작업지침 → 이미지 프롬프트 → 본문** 순서로 되어 있어요. 에디터에는 맨 아래 `▼ 본문 시작` 줄 **다음부터** 붙여 넣어 주세요.

## 1. 게시 정보

| 항목 | 내용 |
|---|---|
| 영역 | ISSUE TRACKER |
| 카테고리 | 입시 |
| 태그 | 입시 · 2028 대입 · UPDATE |
| 날짜/표기 | 기준일 2026.10 · 교육부 발표 기준 |
| 카드 요약문 | (이슈 트래커 카드: 요약 문구 없음) |
| 카드·이미지 기준 색 | soft warm gray (#F3F4F6) with a small coral red accent (#F0503C) |
| 사이트 카드 수정 | 없음 (카드 문구 그대로) |

## 2. 이미지 작업 목록 (총 5장)

| # | 파일명 | 용도 | 비율 | 넣을 위치 | 캡션 |
|---|---|---|---|---|---|
| 0 | 01-hero.png | 대표(썸네일) | 16:9 | 게시글 대표 이미지 칸 (본문에 넣지 않음) | 내신 5등급제, 초등 학부모가 알아둘 3가지 |
| 1 | 01-1.png | 본문 (M) | 3:2 | `무엇이 어떻게 바뀌었나요` 섹션 첫 문단 바로 아래 (`IMAGE-URL-01-1` 자리) | 9등급에서 5등급으로, 등급 칸이 넓어졌어요 |
| 2 | 01-2.png | 본문 (M) | 3:2 | `알아둘 것 1. '1등급'의 의미가 달라져요` 섹션 첫 문단 바로 아래 (`IMAGE-URL-01-2` 자리) | 등급보다 과정이 드러나는 기록이 중요해져요 |
| 3 | 01-3.png | 본문 (M) | 3:2 | `알아둘 것 3. 초등 영어 교실도 이미 바뀌고 있어요` 섹션 첫 문단 바로 아래 (`IMAGE-URL-01-3` 자리) | 보여주고 말하는 활동이 초등 영어 수업에도 들어왔어요 |
| 4 | 01-4.png | 본문 (M) | 3:2 | `그래서 지금, 집에서는 무엇을 하면 좋을까요` 섹션 첫 문단 바로 아래 (`IMAGE-URL-01-4` 자리) | 하루 한두 문장, 말하고 쓰는 경험부터 시작해요 |

## 3. 영문 프롬프트

### 대표 이미지 — 01-hero.png (16:9)

```
A parent and an elementary school child sitting together at a kitchen table, looking toward a simple staircase of five wide pastel steps that rises to a distant high school building; the top step has a coral accent. Soft flat editorial illustration with subtle paper grain, rounded friendly shapes, warm natural light, calm and hopeful mood, limited pastel palette dominated by soft warm gray (#F3F4F6) with a small coral red accent (#F0503C), clean composition with generous negative space. People are Korean elementary school children and parents with simple, friendly faces. Original artwork, not imitating any existing book or brand. No text, no letters, no numbers, no logos, no watermarks. Horizontal 16:9 composition.
```

### 본문 이미지 1 — 01-1.png (3:2)
- 위치: `무엇이 어떻게 바뀌었나요` 섹션 첫 문단 바로 아래
- 캡션: 9등급에서 5등급으로, 등급 칸이 넓어졌어요

```
Two stacks of soft building blocks side by side as a minimal infographic: the left stack has nine thin layers, the right stack has five wider layers, with a gentle arrow from left to right. Soft flat editorial illustration with subtle paper grain, rounded friendly shapes, warm natural light, calm and hopeful mood, limited pastel palette dominated by soft warm gray (#F3F4F6) with a small coral red accent (#F0503C), clean composition with generous negative space. People are Korean elementary school children and parents with simple, friendly faces. Original artwork, not imitating any existing book or brand. No text, no letters, no numbers, no logos, no watermarks. Horizontal 3:2 composition.
```

### 본문 이미지 2 — 01-2.png (3:2)
- 위치: `알아둘 것 1. '1등급'의 의미가 달라져요` 섹션 첫 문단 바로 아래
- 캡션: 등급보다 과정이 드러나는 기록이 중요해져요

```
An open school portfolio folder on a desk with drawings, presentation slides and handwritten essay pages (only abstract squiggle lines) spilling out, representing a record of the learning process. Soft flat editorial illustration with subtle paper grain, rounded friendly shapes, warm natural light, calm and hopeful mood, limited pastel palette dominated by soft warm gray (#F3F4F6) with a small coral red accent (#F0503C), clean composition with generous negative space. People are Korean elementary school children and parents with simple, friendly faces. Original artwork, not imitating any existing book or brand. No text, no letters, no numbers, no logos, no watermarks. Horizontal 3:2 composition.
```

### 본문 이미지 3 — 01-3.png (3:2)
- 위치: `알아둘 것 3. 초등 영어 교실도 이미 바뀌고 있어요` 섹션 첫 문단 바로 아래
- 캡션: 보여주고 말하는 활동이 초등 영어 수업에도 들어왔어요

```
A bright elementary school English classroom where one child stands and presents a hand-drawn picture poster to classmates while the teacher smiles. Soft flat editorial illustration with subtle paper grain, rounded friendly shapes, warm natural light, calm and hopeful mood, limited pastel palette dominated by soft warm gray (#F3F4F6) with a small coral red accent (#F0503C), clean composition with generous negative space. People are Korean elementary school children and parents with simple, friendly faces. Original artwork, not imitating any existing book or brand. No text, no letters, no numbers, no logos, no watermarks. Horizontal 3:2 composition.
```

### 본문 이미지 4 — 01-4.png (3:2)
- 위치: `그래서 지금, 집에서는 무엇을 하면 좋을까요` 섹션 첫 문단 바로 아래
- 캡션: 하루 한두 문장, 말하고 쓰는 경험부터 시작해요

```
A parent and child at home in the evening; the child reads a short sentence aloud from a small notebook while the parent listens attentively under warm lamp light. Soft flat editorial illustration with subtle paper grain, rounded friendly shapes, warm natural light, calm and hopeful mood, limited pastel palette dominated by soft warm gray (#F3F4F6) with a small coral red accent (#F0503C), clean composition with generous negative space. People are Korean elementary school children and parents with simple, friendly faces. Original artwork, not imitating any existing book or brand. No text, no letters, no numbers, no logos, no watermarks. Horizontal 3:2 composition.
```

## 4. 작업 순서

1. 위 프롬프트로 이미지 5장을 생성해요. 비율은 표대로 맞추고, 글자가 생긴 컷은 다시 생성해요.
2. 이미지를 업로드해서 URL을 받아요.
3. 본문의 `IMAGE-URL-01-1` ~ `IMAGE-URL-01-4`를 업로드한 URL로 바꿔요.
4. `01-hero.png`는 게시글 대표 이미지(썸네일) 칸에 등록해요.
5. 미리보기로 이미지 위치와 캡션을 확인한 뒤 발행해요.

▼ 본문 시작 (이 줄 아래부터 에디터에 붙여넣기) ▼

# 내신 5등급제 전환, 초등 학부모가 알아둘 3가지

"고등학교 내신이 5등급으로 바뀌었다는데, 우리 아이는 아직 초등학생이니 상관없겠지?" 학부모님들께 자주 듣는 질문이에요. 세부 제도는 아이가 고등학생이 될 때까지 또 바뀔 수 있지만, 이번 변화가 가리키는 방향은 지금부터 알아둘 만해요. 오늘은 내신 5등급제가 무엇이 달라졌는지, 그리고 초등 학부모가 지금 알아두면 좋은 세 가지를 차분히 정리해 볼게요.

::: callout
**한눈에 보기**
교육부는 2023년 12월 「2028 대학입시제도 개편 확정안」을 발표했어요. 2025년 고1부터 고교 내신은 9등급에서 5등급 체제로 바뀌었고, 성취평가(A~E)와 상대평가 등급을 함께 적는 방식으로 운영되고 있어요.
:::

## 무엇이 어떻게 바뀌었나요

이전까지 고교 내신은 상위 4%까지 1등급을 받는 9등급 상대평가였어요. 새 제도에서는 등급이 다섯 칸으로 줄면서 각 등급의 폭이 넓어졌어요.

![M:9등급에서 5등급으로, 등급 칸이 넓어졌어요](IMAGE-URL-01-1)

-- 1등급: 상위 10%까지
-- 2등급: 상위 34%까지 (누적)
-- 3등급: 상위 66%까지 (누적)
-- 4등급: 상위 90%까지 (누적)
-- 5등급: 나머지 10%

또 하나의 변화는 **절대평가와 상대평가의 병기**예요. 학생부에는 성취 수준을 나타내는 A~E 성취도와 5등급 상대평가 결과가 함께 기록돼요. 다만 사회·과학 융합선택 과목처럼 일부 과목은 성취도만 적도록 정해져 있어요.

2025년에 고1이었던 학생들이 2028학년도 대입을 치르는 첫 세대예요. 2026년 현재는 이 학생들을 포함한 고1·2학년이 5등급 체제로 평가받고 있어요. 2024년에 입학한 지금의 고3은 기존 9등급 체제를 적용받아요.

::: callout
**아직 바뀔 수 있어요**
국가교육위원회는 2028~2037년에 적용할 국가교육발전계획을 마련하면서 고교 내신을 절대평가로 바꾸는 방안 등을 논의하고 있어요. 지금 초등학생이 고등학교에 들어갈 무렵에는 등급 체계가 달라질 수 있다는 뜻이에요. 다만 2026년 10월 현재 확정된 내용은 아니에요.
:::

---

## 알아둘 것 1. '1등급'의 의미가 달라져요

1등급 비율이 4%에서 10%로 넓어지면서, 같은 1등급 안에 있는 학생 수가 훨씬 많아졌어요. 숫자만으로는 학생 사이의 차이를 보여주기 어려워진 셈이에요.

![M:등급보다 과정이 드러나는 기록이 중요해져요](IMAGE-URL-01-2)

그래서 입시 전문가들 사이에서는 대학이 등급 외의 정보, 즉 **수업 시간에 무엇을 했고 어떻게 성장했는지**를 더 꼼꼼히 볼 것이라는 전망이 많아요. 과목별 세부능력 및 특기사항, 수행평가 결과물, 서술형·논술형 답안처럼 '과정이 드러나는 기록'의 무게가 커진다는 뜻이에요.

> 등급 칸이 줄어들수록, 그 칸 안을 채우는 이야기가 중요해져요.

초등 시기에 이 변화를 떠올려야 하는 이유도 여기에 있어요. 과정이 드러나는 공부 습관, 자기 생각을 말과 글로 정리하는 힘은 고등학교에 가서 단기간에 만들기 어렵기 때문이에요.

## 알아둘 것 2. 영어는 '수능 절대평가 + 내신 병기' 구조예요

2028학년도 수능에서도 영어는 지금처럼 **절대평가**가 유지돼요. 원점수 90점 이상이면 누구나 1등급을 받는 방식이에요. 반면 학교 내신에서는 영어 과목도 성취도와 5등급 상대평가가 함께 기록돼요.

이 구조가 의미하는 바는 분명해요.

== 수능 영어는 '기준 점수를 안정적으로 넘는 실력'이 목표가 돼요.
== 내신 영어는 수업 참여, 발표, 쓰기 같은 수행 과정이 성적과 기록에 함께 반영돼요.
== 결국 문제 풀이만으로는 부족하고, 영어로 말하고 쓰는 경험이 쌓여 있어야 유리해요.

## 알아둘 것 3. 초등 영어 교실도 이미 바뀌고 있어요

2022 개정 교육과정은 2024년 초1·2학년부터 순차 적용되어 2026년에는 초등 전 학년에 적용되고 있어요. 초등 영어는 3학년부터 정규 교과로 배우는데, 새 교육과정에서는 영역이 **이해**(듣기·읽기·보기)와 **표현**(말하기·쓰기·제시하기)으로 다시 묶였어요.

![M:보여주고 말하는 활동이 초등 영어 수업에도 들어왔어요](IMAGE-URL-01-3)

여기서 눈여겨볼 단어가 '제시하기'예요. 그림, 사진, 발표 자료 등을 활용해 자기 생각을 보여주는 활동까지 영어 학습의 범위로 들어왔다는 뜻이에요. 고등학교의 발표·토론 중심 수업, 서술형 평가와 자연스럽게 이어지는 흐름이에요.

---

## 학년별로 지금 챙기면 좋은 것

같은 초등학생이라도 학년에 따라 준비의 모양은 조금씩 달라요.

**초등 1~2학년**
학교에서 영어를 정식으로 배우기 전이에요. 이 시기에는 영어 노래, 그림책, 짧은 영상으로 소리에 익숙해지는 것만으로도 충분해요. 무엇보다 영어를 즐거운 경험으로 기억하게 해 주는 것이 핵심이에요.

**초등 3~4학년**
학교 영어 수업이 시작되는 시기예요. 수업에서 배운 표현을 집에서 한 번 더 말해 보게 하고, 아이가 무엇을 배웠는지 영어 단어 하나라도 들려 달라고 해 보세요. 배운 것을 다시 꺼내 보는 습관이 생겨요.

**초등 5~6학년**
문장 쓰기와 발표가 본격적으로 시작돼요. 짧은 영어 일기, 1분 발표처럼 결과물이 남는 활동을 꾸준히 해 보세요. 중학교 수행평가와 서술형 평가로 자연스럽게 이어지는 연습이 돼요.

## 자주 묻는 질문

**Q. 등급 폭이 넓어졌으니 내신 부담이 줄어드는 건가요?**
1등급을 받는 학생 비율이 늘어난 것은 맞아요. 하지만 여전히 상대평가라서 한 등급 차이가 주는 무게는 오히려 커졌다는 지적도 있어요. 등급만으로는 차이를 보여주기 어려워진 만큼 수행평가나 학생부 기록처럼 다른 부분의 중요성도 커질 수 있어요. 부담이 사라졌다기보다 부담의 모양이 바뀌었다고 보는 편이 정확해요.

**Q. 초등 때 선행학습을 더 해야 할까요?**
제도 변화의 방향을 보면, 많이 앞서 배우는 것보다 배운 것을 자기 말로 설명하고 표현하는 힘이 더 중요해지고 있어요. 진도보다 깊이를 먼저 챙겨 주세요.

---

## 그래서 지금, 집에서는 무엇을 하면 좋을까요

거창한 준비가 필요한 건 아니에요. 다만 방향은 분명히 잡아두는 게 좋아요.

![M:하루 한두 문장, 말하고 쓰는 경험부터 시작해요](IMAGE-URL-01-4)

-- **결과보다 과정 묻기**: "몇 점이야?" 대신 "어떤 문제가 재미있었어?"라고 물어봐 주세요.
-- **짧게라도 말하고 쓰기**: 하루 한두 문장이라도 영어로 자기 생각을 표현하는 경험을 쌓아 주세요.
-- **기록 남기기**: 아이가 만든 결과물, 발표 영상, 쓴 글을 모아두면 성장 과정이 눈에 보여요.
-- **조급해하지 않기**: 고교 내신은 아직 먼 이야기이고, 그사이 제도도 달라질 수 있어요. 지금은 영어를 '좋아하는 상태'를 지키는 게 가장 큰 준비예요.

::: callout
**정리하면**
내신 5등급제는 '몇 등급이냐'보다 '어떻게 배웠느냐'를 더 묻는 방향의 변화예요. 초등 시기에는 점수 경쟁보다 말하고 쓰는 습관, 과정을 기록하는 습관을 만들어 두는 것이 가장 현실적인 대비예요.
:::

변화의 소식이 들릴 때마다 불안해지기 쉽지만, 방향을 알고 나면 오히려 마음이 가벼워져요. 지금 아이와 함께하는 작은 습관이 가장 든든한 준비라는 점을 기억해 주세요.

앞서 말씀드린 것처럼 고교 평가 제도는 앞으로도 바뀔 수 있어요. 아이가 고등학생이 될 무렵의 최신 안내는 교육부와 각 시·도교육청 발표를 꼭 함께 확인해 주세요. 저희도 변화가 생기면 이 이슈 트래커에서 계속 업데이트할게요.
