# [작업지침] 08. 알파벳만 아는 아이, 12주 뒤 첫 문장을 읽기까지의 로드맵

> 이 파일은 **작업지침 → 이미지 프롬프트 → 본문** 순서로 되어 있어요. 에디터에는 맨 아래 `▼ 본문 시작` 줄 **다음부터** 붙여 넣어 주세요.

## 1. 게시 정보

| 항목 | 내용 |
|---|---|
| 영역 | 새로운 이야기 |
| 제목 | 알파벳만 아는 아이, 12주 뒤 첫 문장을 읽기까지의 로드맵 |
| 기존 제목 | 알파벳부터 시작하는 아이, 첫 3개월 로드맵 (사이트 카드 교체 필요) |
| 카드 요약문 | 파닉스부터 첫 문장까지, 주차별로 무엇을 하면 되는지 정리했어요. (유지) |
| 태그 | 아티클 · Starter |
| 날짜/표기 | 2026.09.25 · 5분 읽기 |
| 카드·이미지 기준 색 | pale lime (#EEF6D8) |
| 카드 문구·카드뉴스 표지 | `98-카드문구-교체안.md` 참고 |

## 2. 이미지 작업 목록 (총 5장)

| # | 파일명 | 용도 | 비율 | 넣을 위치 | 캡션 |
|---|---|---|---|---|---|
| 0 | 08-hero.png | 대표(썸네일) | 16:9 | 게시글 대표 이미지 칸 (본문에 넣지 않음) | 알파벳만 아는 아이, 12주 뒤 첫 문장을 읽기까지의 로드맵 |
| 1 | 08-1.png | 본문 (M) | 3:2 | `1개월 차: 소리와 친해지기` 섹션 제목 바로 아래(첫 소제목보다 위) (`IMAGE-URL-08-1` 자리) | 노래와 카드로 소리와 친해지는 첫 달 |
| 2 | 08-2.png | 본문 (M) | 3:2 | `2개월 차: 소리를 이어 단어 읽기` 섹션 안, "한 주가 끝나면…" 블록 바로 아래 (`IMAGE-URL-08-2` 자리) | 놀이처럼 익히는 단어와 사이트 워드 |
| 3 | 08-3.png | 본문 (M) | 3:2 | `3개월 차: 첫 문장 만들기` 섹션 안, "아이가 만든 문장을 그림과 함께…" 블록 바로 아래 (`IMAGE-URL-08-3` 자리) | 3개월의 성과, 냉장고에 붙인 나의 첫 문장 |
| 4 | 08-4.png | 본문 (M) | 3:2 | `하루 15분, 이렇게 나눠 보세요` 섹션 첫 문단 바로 아래 (`IMAGE-URL-08-4` 자리) | 노래, 오늘의 활동, 그림책으로 나눈 15분 |

## 3. 영문 프롬프트

### 대표 이미지 — 08-hero.png (16:9)

```
Colorful wooden toy blocks decorated only with colors and simple patterns form a stepping path that leads to a small open picture book; a child happily steps along the blocks. Soft flat editorial illustration with subtle paper grain, rounded friendly shapes, warm natural light, calm and hopeful mood, limited pastel palette dominated by pale lime (#EEF6D8), clean composition with generous negative space. People are Korean elementary school children and parents with simple, friendly faces. Original artwork, not imitating any existing book or brand. No text, no letters, no numbers, no logos, no watermarks. Horizontal 16:9 composition.
```

### 본문 이미지 1 — 08-1.png (3:2)
- 위치: `1개월 차: 소리와 친해지기` 섹션 제목 바로 아래(첫 소제목보다 위)
- 캡션: 노래와 카드로 소리와 친해지는 첫 달

```
A parent and child singing together with musical notes floating in the air, picture flashcards of an apple, a ball and a cat scattered on the floor. Soft flat editorial illustration with subtle paper grain, rounded friendly shapes, warm natural light, calm and hopeful mood, limited pastel palette dominated by pale lime (#EEF6D8), clean composition with generous negative space. People are Korean elementary school children and parents with simple, friendly faces. Original artwork, not imitating any existing book or brand. No text, no letters, no numbers, no logos, no watermarks. Horizontal 3:2 composition.
```

### 본문 이미지 2 — 08-2.png (3:2)
- 위치: `2개월 차: 소리를 이어 단어 읽기` 섹션 안, "한 주가 끝나면…" 블록 바로 아래
- 캡션: 놀이처럼 익히는 단어와 사이트 워드

```
Picture cards spread across the floor like a game board; the child joyfully steps on one card as the parent points to it. Soft flat editorial illustration with subtle paper grain, rounded friendly shapes, warm natural light, calm and hopeful mood, limited pastel palette dominated by pale lime (#EEF6D8), clean composition with generous negative space. People are Korean elementary school children and parents with simple, friendly faces. Original artwork, not imitating any existing book or brand. No text, no letters, no numbers, no logos, no watermarks. Horizontal 3:2 composition.
```

### 본문 이미지 3 — 08-3.png (3:2)
- 위치: `3개월 차: 첫 문장 만들기` 섹션 안, "아이가 만든 문장을 그림과 함께…" 블록 바로 아래
- 캡션: 3개월의 성과, 냉장고에 붙인 나의 첫 문장

```
A child's crayon drawing of a dog stuck to a refrigerator door with a magnet, and the child proudly pointing at it. Soft flat editorial illustration with subtle paper grain, rounded friendly shapes, warm natural light, calm and hopeful mood, limited pastel palette dominated by pale lime (#EEF6D8), clean composition with generous negative space. People are Korean elementary school children and parents with simple, friendly faces. Original artwork, not imitating any existing book or brand. No text, no letters, no numbers, no logos, no watermarks. Horizontal 3:2 composition.
```

### 본문 이미지 4 — 08-4.png (3:2)
- 위치: `하루 15분, 이렇게 나눠 보세요` 섹션 첫 문단 바로 아래
- 캡션: 노래, 오늘의 활동, 그림책으로 나눈 15분

```
A simple round clock face without numbers divided into three colored segments, each holding an icon: a music note, a puzzle piece and an open book. Soft flat editorial illustration with subtle paper grain, rounded friendly shapes, warm natural light, calm and hopeful mood, limited pastel palette dominated by pale lime (#EEF6D8), clean composition with generous negative space. People are Korean elementary school children and parents with simple, friendly faces. Original artwork, not imitating any existing book or brand. No text, no letters, no numbers, no logos, no watermarks. Horizontal 3:2 composition.
```

## 4. 작업 순서

1. 위 프롬프트로 이미지 5장을 생성해요. 비율은 표대로 맞추고, 글자가 생긴 컷은 다시 생성해요.
2. 이미지를 업로드해서 URL을 받아요.
3. 본문의 `IMAGE-URL-08-1` ~ `IMAGE-URL-08-4`를 업로드한 URL로 바꿔요.
4. `08-hero.png`는 게시글 대표 이미지(썸네일) 칸에 등록해요.
5. 미리보기로 이미지 위치와 캡션을 확인한 뒤 발행해요.

▼ 본문 시작 (이 줄 아래부터 에디터에 붙여넣기) ▼

# 알파벳만 아는 아이, 12주 뒤 첫 문장을 읽기까지의 로드맵

"주변 친구들은 벌써 영어책을 읽는다는데, 우리 아이는 이제 알파벳을 배워요." 이렇게 조급한 마음으로 시작하시는 부모님이 많아요. 하지만 영어는 출발 시점보다 **처음 3개월을 어떻게 보내느냐**가 훨씬 중요해요. 이 시기에 영어를 '재미있는 소리'로 만나면, 그 뒤의 속도는 생각보다 빨라져요. 파닉스부터 첫 문장까지, 주차별로 무엇을 하면 좋을지 정리했어요.

::: callout
**로드맵을 시작하기 전에**
아래 일정은 하루 15~20분, 주 5일 정도를 기준으로 한 예시예요. 아이마다 속도가 다르니, 한 단계를 충분히 즐긴 뒤 다음으로 넘어가 주세요. 늦어지는 건 실패가 아니라 다지는 시간이에요.
:::

## 1개월 차: 소리와 친해지기

![M:노래와 카드로 소리와 친해지는 첫 달](IMAGE-URL-08-1)

**1~2주 차, 알파벳 이름과 모양**
알파벳 노래를 부르며 26개 글자의 이름을 익혀요. 대문자와 소문자를 짝지어 보는 카드 놀이도 좋아요. 이 시기엔 쓰기보다 눈과 귀로 익히는 게 먼저예요.

**3~4주 차, 글자가 내는 소리**
이제 글자의 '이름'이 아니라 '소리'를 배울 차례예요. b는 '비'가 아니라 /b/ 소리를 낸다는 걸 알려 주세요. apple의 a, ball의 b처럼 단어와 함께 들려주면 훨씬 잘 기억해요.

-- 집 안 물건을 가리키며 첫소리 맞히기 놀이
-- 같은 소리로 시작하는 단어 모으기 (cat, cup, car)

> 파닉스의 목표는 '읽기'가 아니라, 글자와 소리를 연결하는 감각을 깨우는 거예요.

---

## 2개월 차: 소리를 이어 단어 읽기

**5~6주 차, 단모음과 세 글자 단어**
a, e, i, o, u의 짧은 소리를 익히고, 자음-모음-자음으로 된 세 글자 단어를 읽어 봐요. c-a-t를 천천히 이어 말하다가 cat으로 합쳐 읽는 순간, 아이 얼굴이 환해지는 걸 보실 수 있을 거예요.

**7~8주 차, 사이트 워드 만나기**
the, you, said, was처럼 자주 나오지만 파닉스 규칙만으로는 읽기 어려운 단어들이 있어요. 이런 단어와 I, is, a처럼 아주 자주 쓰이는 단어는 통째로 보고 바로 읽을 수 있게 익혀 두면 좋아요. 이런 단어를 '사이트 워드(sight words)'라고 해요. 하루에 두세 개씩, 카드로 보고 바로 읽는 연습을 해 주세요.

== 단어 카드를 바닥에 펼치고, 부모님이 부르는 단어를 찾아 밟기
== 그림책에서 오늘 배운 사이트 워드 찾아 표시하기
== 한 주가 끝나면 그동안 익힌 단어를 모아 '나만의 단어장' 만들기

![M:놀이처럼 익히는 단어와 사이트 워드](IMAGE-URL-08-2)

---

## 3개월 차: 첫 문장 만들기

**9~10주 차, 짧은 문장 읽기**
"I see a cat.", "It is red."처럼 사이트 워드와 세 글자 단어를 조합한 문장을 읽어 봐요. 문장 그림책(리더스북)의 첫 단계 책이 이 시기에 잘 맞아요.

**11~12주 차, 내 문장 말하고 쓰기**
드디어 첫 문장을 만들어 볼 시간이에요. "I like □."처럼 빈칸 하나짜리 틀로 시작하면 부담이 없어요.

-- I like dogs.
-- I like pizza.
-- I like my mom.

아이가 만든 문장을 그림과 함께 종이에 써서 냉장고에 붙여 주세요. 3개월의 성과가 눈에 보이는 순간이에요.

![M:3개월의 성과, 냉장고에 붙인 나의 첫 문장](IMAGE-URL-08-3)

## 하루 15분, 이렇게 나눠 보세요

-- **3분, 노래로 시작**: 알파벳 노래나 파닉스 노래로 영어 시간을 여는 신호를 만들어요.
-- **7분, 오늘의 활동**: 주차별 로드맵에 맞춰 소리, 단어, 문장 중 하나에 집중해요.
-- **5분, 그림책으로 마무리**: 그날 배운 소리나 단어가 나오는 그림책을 함께 읽어요.

![M:노래, 오늘의 활동, 그림책으로 나눈 15분](IMAGE-URL-08-4)

매일 같은 순서로 진행하면 아이는 다음에 무엇을 할지 알고 있어서 훨씬 편안하게 참여해요.

## 3개월 동안 꼭 지켜주세요

**매일 듣기는 계속해요**
파닉스 공부와 별개로 영어 동요, 그림책 음원, 짧은 영상처럼 귀로 듣는 시간은 매일 이어가 주세요. 많이 들은 아이가 소리를 더 빨리 구별해요.

**쓰기는 천천히 해도 돼요**
글자를 따라 쓰는 활동은 좋지만, 손 힘이 약한 아이에게 많은 쓰기는 영어 자체를 싫어하게 만들 수 있어요. 읽기보다 한 걸음 늦게 가도 괜찮아요.

**비교하지 않아요**
다른 아이의 진도와 비교하는 순간, 아이는 영어를 평가받는 과목으로 느끼기 시작해요. 어제의 우리 아이와만 비교해 주세요.

::: callout
**3개월 로드맵 한눈에 보기**
1개월 차: 알파벳 이름과 소리 익히기
2개월 차: 단모음 세 글자 단어 읽기, 사이트 워드 익히기
3개월 차: 짧은 문장 읽기, 내 문장 말하고 쓰기
:::

## 자주 묻는 질문

**Q. 알파벳 이름과 소리가 헷갈린다고 해요.**
처음에는 자연스러운 일이에요. 'b는 이름이 비, 소리는 /b/'처럼 이름과 소리를 따로 정리한 카드를 만들어 주세요. 소리를 낼 때는 입 모양을 과장해서 보여주면 아이가 더 쉽게 구별해요.

**Q. b와 d를 자꾸 바꿔 써요.**
초기 학습자에게 흔한 현상이에요. 'bed'라는 단어를 침대 모양으로 그려 보는 놀이가 도움이 돼요. b와 d의 세로 막대가 침대의 머리판과 발판이 되고, 둥근 부분이 그 사이의 매트리스가 된다고 보여주면 기억하기 쉬워요.

**Q. 하루 15분으로 정말 충분할까요?**
처음 3개월은 길게 하는 것보다 매일 하는 것이 더 중요해요. 15분 동안 집중해서 즐겁게 했다면, 아이가 더 하고 싶어 할 때 멈추는 것도 좋은 방법이에요. 다음 날 다시 영어를 기다리게 되거든요.

**Q. 학습지나 앱을 같이 써도 될까요?**
물론이에요. 다만 화면 속 활동만으로 끝나지 않도록, 앱에서 배운 단어를 실제 물건과 연결해 말해 보는 시간을 함께 가져 주세요.

## 3개월 뒤, 그다음은?

로드맵을 꾸준히 따라왔다면, 아이는 쉬운 문장을 스스로 읽고 자기 이야기를 한 문장으로 말해 보는 단계에 가까워져 있을 거예요. 물론 아이에 따라 더 걸릴 수도 있고, 그래도 괜찮아요. 다음 단계에서는 장모음과 이중자음 같은 조금 더 복잡한 파닉스 규칙을 배우고, 짧은 이야기책을 읽으며 문장의 양을 늘려 가요.

이때도 가장 중요한 원칙은 같아요. 매일 조금씩, 즐겁게, 비교하지 않고. 처음 3개월 동안 지킨 이 원칙이 앞으로 이어질 영어 공부의 기본 리듬이 돼요. 아이가 스스로 영어책을 꺼내 오는 날이 생각보다 빨리 찾아올 거예요.

알파벳부터 시작한다는 건 늦은 게 아니라, 기초부터 단단하게 쌓을 기회를 가졌다는 뜻이에요. 첫 3개월, 아이와 함께 즐겁게 걸어가 보세요.
