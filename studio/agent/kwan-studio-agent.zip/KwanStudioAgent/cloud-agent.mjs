import {randomUUID} from 'node:crypto';
import {startPlanning,getPlanningJob,cancelPlanning} from './agent.mjs';
import {codexStatus} from './codex-client.mjs';
import {decodeMedia} from './render.mjs';
import {modelById} from './src/models.mjs';
import {mergeGenerationResult} from './src/generation-result.mjs';
const API='https://eoljasmgogdcvnytaoax.supabase.co/rest/v1/';
export class CloudAgent{
 constructor(root){this.root=root;this.id=randomUUID();this.busy=false;this.checking=false;}
 async request(path,method='GET',body,prefer){
  if(!this.session)throw Error('실행기 연결이 만료되었습니다.');
  const r=await fetch(API+path,{method,headers:{apikey:this.session.key,Authorization:'Bearer '+this.session.token,'Content-Type':'application/json',...(prefer?{Prefer:prefer}:{})},...(body!==undefined?{body:JSON.stringify(body)}:{})});
  if(!r.ok)throw Error('클라우드 실행기 요청을 확인하지 못했습니다. 로그인 연결을 갱신하세요.');const text=await r.text();return text?JSON.parse(text):null;
 }
 async connect({accessToken,anonKey}){
  if(typeof accessToken!=='string'||accessToken.length>12000||typeof anonKey!=='string'||anonKey.length>4000)throw Error('로그인 연결 형식이 올바르지 않습니다.');
  const test={token:accessToken,key:anonKey};const previous=this.session;
  try{const check=await fetch(API+'rpc/is_agency_owner',{method:'POST',headers:{apikey:anonKey,Authorization:'Bearer '+accessToken,'Content-Type':'application/json'},body:'{}'});if(!check.ok||await check.json()!==true)throw Error('KWAN 전용 실행기입니다.');
   const health=await codexStatus(this.root);if(!health.connected||health.authMode!=='chatgpt')throw Error('이 컴퓨터의 Codex에 ChatGPT 계정으로 먼저 로그인하세요. API 키 방식은 자동으로 사용하지 않습니다.');
   const claims=JSON.parse(Buffer.from(accessToken.split('.')[1],'base64url').toString());if(!claims.sub||!claims.exp||claims.exp*1000<Date.now()+30000)throw Error('로그인을 갱신한 뒤 다시 연결하세요.');
   this.session={...test,userId:claims.sub,expiresAt:claims.exp*1000};clearInterval(this.timer);await this.heartbeat();this.timer=setInterval(()=>this.tick().catch(()=>{}),10000);this.timer.unref();void this.tick().catch(()=>{});return {connected:true,expiresAt:new Date(claims.exp*1000).toISOString()};
  }catch(e){this.session=previous;throw e;}
 }
 async heartbeat(){await this.request('kwan_studio_agents?on_conflict=user_id,id','POST',{user_id:this.session.userId,id:this.id,label:'연결된 Mac의 Codex',last_seen:new Date().toISOString(),expires_at:new Date(this.session.expiresAt).toISOString()},'resolution=merge-duplicates');}
 async generationRequests(){return (await this.request('kwan_studio_jobs?kind=eq.generation&select=*&order=created_at.asc')).map(row=>({...row.payload,id:row.id,status:row.status,createdAt:row.created_at}));}
 async importResult(id,media){
  decodeMedia(media);const rows=await this.request('kwan_studio_jobs?id=eq.'+id+'&kind=eq.generation&select=*'),row=rows[0];if(!row)throw Error('클라우드 생성 요청이 없습니다.');
  if(row.status==='cancelled')throw Error('취소된 요청입니다.');if(row.status==='complete')return {saved:true,alreadyCompleted:true,nodeId:row.result?.node?.id};
  const job={...row.payload,id:row.id,createdAt:row.created_at};if(media.type.split('/')[0]!==modelById(job.model)?.kind)throw Error('요청한 모델과 파일 형식이 다릅니다.');
  const [stored]=await this.request('kwan_studio_projects?id=eq.'+encodeURIComponent(row.project_id)+'&select=*');const project=stored.payload;
  const existing=project.nodes.find(n=>n.id===job.nodeId)||project.nodes.find(n=>n.data.externalRequestId===id);
  let next,node;
  if(existing){job.resultNodeId=existing.id;next=mergeGenerationResult(project,job,media);node=next.nodes.find(n=>n.id===existing.id);}
  else{node={id:randomUUID(),type:'studio',position:{x:100,y:Math.max(0,...project.nodes.map(n=>n.position.y))+500},data:{label:(job.role||job.modelName)+' 결과',type:media.type.split('/')[0],tool:'upload',provider:job.provider,model:job.model,mediaRole:'output',media,prompt:job.prompt,settings:job.settings,externalRequestId:id,resultRequestedAt:job.createdAt}};next={...project,nodes:[...project.nodes,node]};}
  const saved=await this.request('rpc/kwan_studio_save_project','POST',{p_id:project.id,p_payload:next,p_expected_version:stored.version});
  await this.request('kwan_studio_jobs?id=eq.'+id,'PATCH',{status:'complete',result:{media,node,projectVersion:saved.version,baseProjectVersion:stored.version,request:{...job,resultNodeId:node.id}},completed_at:new Date().toISOString()});
  return {saved:true,nodeId:node.id};
 }
 async tick(){
  if(this.checking||!this.session)return;if(this.session.expiresAt<=Date.now()){clearInterval(this.timer);this.session=null;return;}this.checking=true;
  try{await this.heartbeat();if(this.busy)return;const claimed=await this.request('rpc/kwan_studio_claim_planning','POST',{});if(!claimed)return;this.busy=true;void this.run(claimed).finally(()=>{this.busy=false;});}finally{this.checking=false;}
 }
 async run({job,project,projectVersion}){
  let local;try{
   const data=job.payload;if(data.expectedProjectVersion!==undefined&&data.expectedProjectVersion!==projectVersion)throw Error('요청 후 프로젝트가 다른 화면에서 수정되었습니다. 새 내용을 확인한 뒤 기획을 다시 요청하세요.');
   const refs=data.options?.referenceIds||[];if(refs.some(id=>!project.nodes.some(n=>n.id===id)))throw Error('참조 노드가 변경되었습니다. 요청을 다시 확인하세요.');
   const memories=(await this.request('kwan_studio_feedback?kind=eq.approved&select=summary&order=created_at.desc&limit=3')).map(m=>({type:'approved',summary:m.summary}));
   local=await startPlanning(data.request,data.options||{},this.root,memories,async plan=>{
    const final={...plan,visualBoard:{roles:{},notes:'',mode:'images'},revision:project.creativePlan?.revision||0,previousApprovals:[...(project.creativePlan?.previousApprovals||[]),...(project.creativePlan?.approval?[project.creativePlan.approval]:[])]};
    const result=await this.request('rpc/kwan_studio_complete_planning','POST',{p_job_id:job.id,p_lease_token:job.lease_token,p_plan:final,p_project_version:projectVersion});
    if(!result.saved)throw Error('프로젝트가 다른 화면에서 수정되었습니다. 기획 결과는 보관했고 덮어쓰지 않았습니다.');return final;
   });
   for(let i=0;i<240;i++){await new Promise(resolve=>setTimeout(resolve,1000));const current=getPlanningJob(local.id);if(current.status==='complete')return;if(current.status==='failed'||current.status==='cancelled')throw Error(current.error||'기획을 취소했습니다.');
    if(i%3===0){const rows=await this.request('kwan_studio_jobs?id=eq.'+job.id+'&select=status');if(rows[0]?.status==='cancelled'){cancelPlanning(local.id);return;}}
   }cancelPlanning(local.id);throw Error('Codex 응답 시간이 초과되었습니다.');
  }catch(e){if(local)cancelPlanning(local.id);try{await this.request('kwan_studio_jobs?id=eq.'+job.id+'&lease_token=eq.'+job.lease_token+'&status=eq.running','PATCH',{status:'failed',result:{error:e.message},completed_at:new Date().toISOString()});}catch{}}
 }
}
