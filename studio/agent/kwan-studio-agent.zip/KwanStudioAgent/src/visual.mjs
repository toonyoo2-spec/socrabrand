export const visualRoles={style:'전체 톤',product:'제품·주요 소품',character:'인물',location:'공간'};
export function visualSignature(board){return JSON.stringify({roles:board?.roles||{},assetHashes:board?.assetHashes||{},notes:board?.notes||'',mode:board?.mode||'images'});}
export const isVisualApproved=board=>!!board?.approved&&board.approved.content===visualSignature(board);
export function approveVisual(board){if(board.mode!=='text'&&!board.roles?.style)throw new Error('전체 톤을 보여줄 시안을 선택하세요.');if(board.mode==='text'&&!board.notes?.trim())throw new Error('시안 없이 진행할 제작 기준을 작성하세요.');return {...board,approved:{at:new Date().toISOString(),content:visualSignature(board)}};}
export function visualReferences(board){return [...new Set(Object.values(board?.roles||{}).filter(Boolean))];}
const mediaHashes=new WeakMap();
export function mediaFingerprint(media){if(!media)return '';if(mediaHashes.has(media))return mediaHashes.get(media);let h=2166136261;const value=media.url||'';for(let i=0;i<value.length;i++){h^=value.charCodeAt(i);h=Math.imul(h,16777619);}const result=`${media.type}:${value.length}:${(h>>>0).toString(16)}`;mediaHashes.set(media,result);return result;}
export function stampVisual(board,nodes){return {...board,assetHashes:Object.fromEntries(visualReferences(board).map(id=>[id,mediaFingerprint(nodes.find(n=>n.id===id)?.data.media)]))};}
export function isVisualCurrent(board,nodes){if(!board)return true;if(!isVisualApproved(board))return false;if(board.mode==='text')return true;return visualReferences(board).every(id=>{const media=nodes.find(n=>n.id===id)?.data.media;return media?.type.startsWith('image/')&&mediaFingerprint(media)===board.assetHashes?.[id];});}
