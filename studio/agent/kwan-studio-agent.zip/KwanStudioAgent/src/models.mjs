// Magnific catalog checked 2026-11-01; Seedream route uses the inspected Higgsfield web variant, not a remote MCP slug.
export const generationModels=[
 {id:'seedream',name:'Seedream 5.0 Lite',requestedName:'Seedream 5.0',kind:'image',provider:'higgsfield',slug:null,webModel:'seedream_v5_lite',browserUrl:'https://higgsfield.ai/ko/ai/image?model=seedream_v5_lite',execution:'higgsfield_web',defaultResolution:'4k',resolutions:['4k'],availableInChat:true,unlimitedWebVerified:true},
 {id:'midjourney',name:'Midjourney',kind:'image',provider:'midjourney',slug:null,resolutions:[],availableInChat:false,manual:true},
 {id:'nanobanana',name:'Nano Banana Pro',kind:'image',provider:'magnific',slug:'imagen-nano-banana-2',resolutions:['1k','2k','4k'],availableInChat:true},
 {id:'gptimage',name:'GPT 이미지 2.5',kind:'image',provider:'magnific',slug:'gpt-2-mini',resolutions:['1k','2k','4k'],availableInChat:true},
 {id:'seedance',name:'Seedance 2.5',kind:'video',provider:'magnific',slug:'bytedance-seedance-pro-2.5',minDuration:4,maxDuration:30,resolutions:['720p','1080p'],availableInChat:true},
 {id:'kling',name:'Kling 4.0',kind:'video',provider:'magnific',slug:'kling-40',minDuration:3,maxDuration:30,resolutions:['720p','1080p'],availableInChat:true}
];
export const modelById=id=>generationModels.find(m=>m.id===id);
export const isVideoModel=id=>modelById(id)?.kind==='video';
export function generationDuration(id,editDuration){const m=modelById(id);return m?.kind==='video'?Math.max(m.minDuration,Math.min(m.maxDuration,Math.ceil(editDuration))):editDuration;}
