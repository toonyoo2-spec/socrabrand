import {compatiblePorts,portTypes} from './ports.mjs';
export function planGraph(nodes,edges,selected){
 const map=new Map(nodes.map(n=>[n.id,n]));
 const relevant=new Set();
 function ancestors(id){if(relevant.has(id))return;relevant.add(id);edges.filter(e=>e.target===id).forEach(e=>ancestors(e.source));}
 (selected?[selected]:nodes.map(n=>n.id)).forEach(ancestors);
 const visiting=new Set(),visited=new Set(),order=[];
 function walk(id){if(visiting.has(id))throw new Error('순환 연결이 있습니다. 노드 연결을 수정해 주세요.');if(visited.has(id))return;if(!map.has(id))throw new Error('연결 대상 노드를 찾을 수 없습니다.');visiting.add(id);edges.filter(e=>e.target===id).forEach(e=>walk(e.source));visiting.delete(id);visited.add(id);order.push(map.get(id));}
 [...relevant].forEach(walk);
 return order.map(n=>({id:n.id,name:n.data.label,tool:n.data.tool,provider:n.data.provider,prompt:n.data.prompt||'',inputs:edges.filter(e=>e.target===n.id).map(e=>e.source),settings:n.data.settings||{},inputPorts:edges.filter(e=>e.target===n.id).map(e=>({nodeId:e.source,output:e.sourceHandle||null,input:e.targetHandle||null})),outputPorts:n.data.ports?.outputs||[],artifact:n.data.media?{name:n.data.media.name,type:n.data.media.type,role:n.data.mediaRole||'reference'}:null,status:n.data.media?'파일 준비됨':['brief','prompt'].includes(n.data.tool)?'준비됨':['split','compare','image-local','crop-local','director','trim','export','subtitle'].includes(n.data.tool)?'로컬 작업실에서 실행':'외부 실행 연결 필요'}));
}
export function validConnection(c,nodes,edges){
 if(c.source===c.target||!compatiblePorts(c,nodes))return false;
 const map=new Map(nodes.map(n=>[n.id,n]));if(!map.has(c.source)||!map.has(c.target))return false;
 if(edges.some(e=>e.source===c.source&&e.target===c.target&&(e.sourceHandle||null)===(c.sourceHandle||null)&&(e.targetHandle||null)===(c.targetHandle||null)))return false;
 try{planGraph(nodes,[...edges,{...c,id:'candidate'}]);return true;}catch{return false;}
}
export function promptPacket(nodes,edges){return planGraph(nodes,edges).map((n,i)=>`[${i+1}] ${n.name}\n도구: ${n.tool}\n공급자: ${n.provider}\n입력: ${n.inputs.join(', ')||'없음'}\n${n.prompt}\n설정: ${JSON.stringify(n.settings)}\n`).join('\n');}
export function validateProject(p){if(!p||!Array.isArray(p.nodes)||!Array.isArray(p.edges)||p.nodes.length>500)throw new Error('프로젝트 형식이 올바르지 않습니다.');const ids=new Set(p.nodes.map(n=>n.id));if(ids.size!==p.nodes.length||p.nodes.some(n=>!n.id||!n.data||!n.position||!Number.isFinite(n.position.x)||!Number.isFinite(n.position.y)))throw new Error('노드 데이터가 올바르지 않습니다.');for(const n of p.nodes){for(const side of ['inputs','outputs']){const ports=n.data.ports?.[side];if(ports!==undefined&&(!Array.isArray(ports)||ports.length>8||new Set(ports.map(x=>x?.id)).size!==ports.length||ports.some(x=>!x||typeof x.id!=='string'||!x.id||typeof x.name!=='string'||!Object.hasOwn(portTypes,x.type))))throw new Error('입력·출력 포트 형식을 확인하세요.');}}p.edges.forEach(e=>{if(!ids.has(e.source)||!ids.has(e.target))throw new Error('존재하지 않는 노드 연결입니다.');if(!compatiblePorts(e,p.nodes))throw new Error('연결 포트와 자료 유형을 확인하세요.');});planGraph(p.nodes,p.edges);return p;}
