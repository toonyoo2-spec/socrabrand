import {mediaFingerprint} from './visual.mjs';
import {applyNodeData} from './results.mjs';

export function generationBasis(project,job){
 const node=project.nodes.find(n=>n.id===job.nodeId);
 const ids=new Set(job.referenceIds||[]),pending=job.nodeId?[job.nodeId]:[],seen=new Set();
 while(pending.length){const id=pending.pop();for(const e of project.edges||[]){if(e.target===id&&!seen.has(e.source)){seen.add(e.source);ids.add(e.source);pending.push(e.source);}}}
 const snapshot=n=>n?{id:n.id,prompt:n.data.prompt||'',model:n.data.model||'',settings:n.data.settings||{},media:mediaFingerprint(n.data.media)}:null;
 const target=snapshot(node);if(target)delete target.media;
 return JSON.stringify({target,refs:[...ids].sort().map(id=>snapshot(project.nodes.find(n=>n.id===id)))});
}

export function mergeGenerationResult(project,job,media,fallbackNode,{manual=false}={}){
 const id=job.resultNodeId||job.nodeId||fallbackNode?.id;
 const current=project.nodes.find(n=>n.id===id);
 if(!current){if(!fallbackNode)return project;return {...project,nodes:[...project.nodes,fallbackNode]};}
 if(current.data.externalRequestId===job.id&&mediaFingerprint(current.data.media)===mediaFingerprint(media))return project;
 const requestedAt=Date.parse(job.createdAt),currentAt=Date.parse(current.data.resultRequestedAt),selectedAt=Date.parse(current.data.resultSelectedAt);
 if(!manual&&current.data.externalRequestId&&current.data.externalRequestId!==job.id&&((Number.isFinite(currentAt)&&Number.isFinite(requestedAt)&&requestedAt<currentAt)||(Number.isFinite(selectedAt)&&(!Number.isFinite(requestedAt)||requestedAt<=selectedAt))))return project;
 const stale=job.basis?generationBasis(project,job)!==job.basis:current.data.prompt!==job.prompt;
 return applyNodeData(project,id,{media,mediaRole:'output',externalRequestId:job.id,resultStale:stale,generationPrompt:job.prompt,resultRequestedAt:job.createdAt||null,...(manual?{resultSelectedAt:new Date().toISOString()}:{})});
}
