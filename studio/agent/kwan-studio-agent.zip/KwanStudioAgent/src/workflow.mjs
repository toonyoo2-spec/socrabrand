import {isVisualApproved} from './visual.mjs';
import {isVideoModel} from './models.mjs';
// Approval is tied to content, not a mutable status label.
export const reviewItems={intent:'목표·대상·전달 내용',identity:'인물·제품·공간의 고정 기준',shots:'컷별 행동·앵글·연결 동작',sound:'대사·말투·음향·자막',delivery:'길이·화면 비율·출력 조건'};
export const productionStandards={
 camera:'ARRI ALEXA 35',lens:'ARRI Signature Prime',
 identity:'인물의 얼굴·헤어·의상, 제품의 형태·색·로고, 공간과 소품 배치를 고정한다.',
 location:'한 공간 안에서 시간대·광원 방향·소품의 위치를 유지한다.',
 realism:'실사 촬영의 재질 반응과 자연스러운 미세 질감. 모발·직물·목재·유리의 고유 결을 유지하고 반복 무늬·지나친 대칭·인위적 선명도를 피한다. 크기·접촉 그림자·반사·가림 관계를 물리적으로 맞추고, 배경 소품에도 무게와 사용 흔적을 자연스럽게 둔다. 피부를 플라스틱처럼 보정하거나 없는 디테일을 만들지 않는다.',
 performance:'작은 비대칭 표정 변화, 자연스러운 눈 깜빡임과 호흡, 목적이 있는 시선과 손동작. 모공·잔털·나이에 맞는 피부 결을 과장 없이 유지한다. 실제 말하듯 억양·쉼·호흡을 두고 목소리를 일관되게 유지한다. 요청이 없으면 광고 성우처럼 읽지 않는다.',
 continuity:'180도 축·시선·이동 방향·사용하는 손·소품 상태를 유지. 연결 동작은 이전 컷의 끝과 다음 컷의 시작에서 겹쳐 촬영하고 편집에서 이어 붙인다.',
 light:'광원 위치와 크기가 설명되는 조명. 피부·제품의 하이라이트를 보존하고 컷 간 화이트밸런스와 노출을 유지한다.',
 sound:'효과음은 행동과 맞추고 공간음은 컷 사이 이어 유지. 대사·나레이션이 없으면 임의로 추가하지 않는다.',
 delivery:'세부 질감을 우선하며 실제 출력 해상도는 연결 모델의 지원 규격에서 결정한다. 자막·로고는 편집 단계에서 합성한다.'
};
export function planContent(plan){return JSON.stringify({request:plan.request,brief:plan.brief,standards:plan.standards,visualBoard:plan.visualBoard,selectedConceptId:plan.selectedConceptId,scenes:plan.scenes,rules:plan.rules});}
export function isApproved(plan){return !!plan?.approval&&plan.approval.content===planContent(plan);}
export function reviewProblems(plan){const p=[];if(plan?.visualBoard&&!isVisualApproved(plan.visualBoard))p.push('시안 기준을 먼저 확정하세요.');if(!plan?.brief?.subject?.trim())p.push('제작 대상을 입력하세요.');if(!plan?.scenes?.length)p.push('장면을 한 개 이상 작성하세요.');if(!plan?.standards?.identity?.trim())p.push('인물·제품의 고정 기준을 작성하세요.');let total=0;for(const [i,s] of (plan?.scenes||[]).entries()){if(!s.description?.trim()||!s.startState?.trim()||!s.endState?.trim())p.push(`${i+1}번 컷의 행동과 시작·종료 상태를 작성하세요.`);if(!Number.isFinite(s.duration)||s.duration<.1||s.duration>60)p.push(`${i+1}번 컷의 길이는 0.1~60초입니다.`);total+=s.duration;}if(Math.abs(total-(plan?.brief?.duration||0))>.11)p.push('전체 길이와 컷 길이의 합을 맞추세요.');return p;}
export function approvePlan(plan,checks,now=new Date().toISOString()){const problems=reviewProblems(plan);if(problems.length)throw new Error(problems[0]);if(Object.keys(reviewItems).some(k=>!checks[k]))throw new Error('다섯 가지 검토 항목을 확인하세요.');const next={...plan,revision:(plan.revision||0)+1};return {...next,approval:{revision:next.revision,at:now,content:planContent(next),checks:{...checks}}};}
export function productionTasks(plan,target='seedance'){if(!isApproved(plan))throw new Error('최종 기획을 먼저 확정하세요.');const tasks=[];const id=s=>`r${plan.approval.revision}-${s}`;const add=(key,kind,label,dependsOn,sceneId=null)=>{const t={id:id(key),kind,label,dependsOn,sceneId,status:'planned'};tasks.push(t);return t.id;};const references=add('references','reference','참조·일관성 기준 준비',[]);const clips=plan.scenes.map((s,i)=>{const keyframe=add(`keyframe-${s.id}`,'image',`${i+1}번 컷 · 기준 이미지`,[references],s.id);return isVideoModel(target)?add(`video-${s.id}`,'video',`${i+1}번 컷 · 영상 제작`,[keyframe],s.id):keyframe;});const sound=isVideoModel(target)?add('sound','audio','대사·효과음·음악 준비',[references]):null;add('edit','output',isVideoModel(target)?'컷 연결·사운드·자막·최종 검수':'이미지 검토·내보내기',sound?[...clips,sound]:clips);return tasks;}
export function handoffKey(plan,target){return `${plan.approval?.revision||0}:${target}`;}
