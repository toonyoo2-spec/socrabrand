#!/bin/zsh
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
cd "$(dirname "$0")"
if ! command -v node >/dev/null || ! command -v codex >/dev/null; then
  echo "Node.js와 Codex CLI가 필요합니다. 설치 후 Codex에 로그인하고 다시 실행해 주세요."
  read "?Enter를 누르면 닫힙니다. "
  exit 1
fi
echo "Kwan Studio 실행기입니다. 홈페이지에서 이 컴퓨터의 Codex 연결을 누르세요."
echo "이 창을 종료하면 실행기 연결도 종료됩니다."
node server.mjs
read "?Enter를 누르면 닫힙니다. "
