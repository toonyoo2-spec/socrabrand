import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
const execute=promisify(execFile);
// Per-process restrictions: never change the user's global Codex configuration.
export const planningIsolationArgs = [
  '--disable', 'apps', '--disable', 'shell_tool', '--disable', 'multi_agent',
  '-c', 'mcp_servers.newtake={url="https://mcp.newtake.ai",enabled=false}',
  '-c', 'mcp_servers.node_repl={command="false",enabled=false}',
  '-c', 'mcp_servers.cua_repl={command="false",enabled=false}',
];
export async function getPlanningIsolationArgs(root){
 const {stdout}=await execute('codex',['mcp','list','--json'],{cwd:root,maxBuffer:5e6,timeout:10000});
 const servers=JSON.parse(stdout);if(!Array.isArray(servers))throw Error('Codex 도구 설정을 확인하지 못했습니다.');
 return ['--disable','apps','--disable','shell_tool','--disable','multi_agent',...servers.flatMap(s=>['-c',`mcp_servers.${JSON.stringify(s.name)}={command="false",enabled=false}`])];
}
