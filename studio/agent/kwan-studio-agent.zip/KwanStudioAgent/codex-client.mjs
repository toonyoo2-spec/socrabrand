import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {getPlanningIsolationArgs} from './planning-runtime.mjs';

// Official local App Server transport. Tokens stay inside Codex's managed login.
export class CodexClient{
 constructor(root){this.root=root;this.pending=new Map();this.listeners=new Set();this.seq=0;this.closed=false;}
 async start(){
  const isolation=await getPlanningIsolationArgs(this.root);
  this.child=spawn('codex',['app-server',...isolation],{cwd:this.root,stdio:['pipe','pipe','pipe']});
  this.child.stderr.resume();this.child.stdin.on('error',()=>{});
  this.exited=new Promise(resolve=>this.child.once('close',resolve));
  const fail=()=>{this.closed=true;for(const p of this.pending.values())p.reject(new Error('Codex 연결이 종료되었습니다.'));this.pending.clear();for(const cb of this.listeners)cb({method:'client/error'});};
  this.child.on('error',fail);this.child.on('close',fail);
  this.lines=createInterface({input:this.child.stdout});this.lines.on('line',line=>{
   let message;try{message=JSON.parse(line);}catch{return;}
   if(message.id!==undefined&&this.pending.has(message.id)){const p=this.pending.get(message.id);this.pending.delete(message.id);message.error?p.reject(new Error(message.error.message||'Codex 요청에 실패했습니다.')):p.resolve(message.result);}
   else if(message.id!==undefined&&message.method){this.child.stdin.write(JSON.stringify({id:message.id,error:{code:-32601,message:'Interactive tool requests are not enabled for this planning client'}})+'\n');}
   else for(const cb of this.listeners)cb(message);
  });
  await this.request('initialize',{clientInfo:{name:'kwan_studio',title:'Kwan Studio',version:'0.2.0'}});
  this.notify('initialized',{});return this;
 }
 notify(method,params){if(this.closed)throw Error('Codex 연결이 닫혔습니다.');this.child.stdin.write(JSON.stringify({method,params})+'\n');}
 request(method,params,timeoutMs=30000){return new Promise((resolve,reject)=>{
  if(this.closed)return reject(Error('Codex 연결이 닫혔습니다.'));
  const id=++this.seq,timer=setTimeout(()=>{this.pending.delete(id);reject(Error('Codex 연결 응답 시간이 초과되었습니다.'));},timeoutMs);
  this.pending.set(id,{resolve:v=>{clearTimeout(timer);resolve(v);},reject:e=>{clearTimeout(timer);reject(e);}});
  this.child.stdin.write(JSON.stringify({method,id,params})+'\n');
 });}
 async close(){if(!this.child)return;this.child.kill('SIGTERM');const timer=setTimeout(()=>this.child.kill('SIGKILL'),1500);await this.exited;clearTimeout(timer);this.lines?.close();}
}

export async function codexStatus(root){const client=new CodexClient(root);try{
 await client.start();const data=await client.request('account/read',{refreshToken:false});
 return {connected:!!data.account,transport:'app-server-stdio',authMode:data.account?.type||null,checkedAt:new Date().toISOString(),planningToolsEnabled:false,automaticBrowserExecution:false};
}finally{await client.close();}}

export async function runCodexPlanning(root,prompt,schema,{signal,onStage=()=>{}}={}){
 const client=new CodexClient(root);let abort,deadline,finish;
 try{
  abort=()=>client.child?.kill('SIGTERM');signal?.addEventListener('abort',abort,{once:true});
  if(signal?.aborted)throw Error('기획 작성을 취소했습니다.');
  await client.start();if(signal?.aborted)throw Error('기획 작성을 취소했습니다.');const auth=await client.request('account/read',{refreshToken:false});if(auth.account?.type!=='chatgpt')throw Error('Codex에 ChatGPT 계정으로 로그인하세요. API 키 방식은 별도 승인 없이 사용하지 않습니다.');
  onStage('Codex 연결됨 · 제작 조건을 전달하고 있습니다.');
  const {thread}=await client.request('thread/start',{cwd:root,ephemeral:true,approvalPolicy:'never',sandbox:'read-only'});
  const messages=new Map();let turnId;
  const completed=new Promise((resolve,reject)=>{
   deadline=setTimeout(()=>reject(Error('기획 응답 시간이 초과되었습니다.')),180000);
   finish=event=>{const p=event.params||{};
    if(event.method==='client/error')return reject(Error(signal?.aborted?'기획 작성을 취소했습니다.':'Codex 연결이 종료되었습니다.'));
    if(p.threadId!==thread.id)return;
    if(event.method==='turn/started'){turnId=p.turn?.id;onStage('Codex가 구성안과 컷별 연출을 작성하고 있습니다.');}
    if(event.method==='item/completed'&&p.item?.type==='agentMessage')messages.set(p.item.id,p.item.text);
    if(event.method==='turn/completed'){
     if(p.turn?.status!=='completed')return reject(Error(p.turn?.error?.message||'Codex 기획을 완료하지 못했습니다.'));
     const items=p.turn.items||[];for(const item of items)if(item.type==='agentMessage')messages.set(item.id,item.text);
     const text=[...messages.values()].at(-1);if(!text)return reject(Error('Codex가 기획 결과를 반환하지 않았습니다.'));
     resolve({text,threadId:thread.id,turnId:p.turn.id||turnId});
    }
   };client.listeners.add(finish);
  });
  // Attach the completion handler before starting; avoid losing a fast response.
  completed.catch(()=>{});
  await client.request('turn/start',{threadId:thread.id,input:[{type:'text',text:prompt}],outputSchema:schema});
  return await completed;
 }finally{clearTimeout(deadline);if(finish)client.listeners.delete(finish);if(abort)signal?.removeEventListener('abort',abort);await client.close();}
}
