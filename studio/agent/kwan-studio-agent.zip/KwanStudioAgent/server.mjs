import http from 'node:http';
import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {validateProject} from './src/engine.mjs';
import {startRender,getRender,getRenderFile} from './render.mjs';
import {normalizeScenes} from './src/production.mjs';
import {startPlanning,getPlanningJob,cancelPlanning} from './agent.mjs';
import {createGenerationRequest,requestInstruction,samePendingRequest} from './requests.mjs';
import {decodeMedia} from './render.mjs';
import {applyNodeData} from './src/results.mjs';
import {randomUUID} from 'node:crypto';
import {codexStatus} from './codex-client.mjs';
import {CloudAgent} from './cloud-agent.mjs';
import {mergeGenerationResult} from './src/generation-result.mjs';
const root=path.dirname(fileURLToPath(import.meta.url)),dir=path.join(root,'.local');
const cloudAgent=new CloudAgent(root),linkNonces=new Map();
await mkdir(dir,{recursive:true});
let store={projects:[],connections:{}};
try{store=JSON.parse(await readFile(path.join(dir,'workspace.json'),'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
let pending=Promise.resolve();
async function persist(){const snapshot=JSON.stringify(store);pending=pending.then(async()=>{await writeFile(path.join(dir,'workspace.tmp'),snapshot,{mode:0o600});await rename(path.join(dir,'workspace.tmp'),path.join(dir,'workspace.json'));});await pending;}
const send=(res,code,data)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
const server=http.createServer(async(req,res)=>{
 try{
 const url=new URL(req.url,'http://localhost');
 if(req.headers.host&&!/^((127\.0\.0\.1|localhost):\d+)$/.test(req.headers.host))return send(res,403,{error:'로컬 호스트만 허용됩니다.'});
 if(req.method!=='GET'&&req.headers.origin&&!['http://127.0.0.1:4317','http://localhost:4317','http://127.0.0.1:4318'].includes(req.headers.origin))return send(res,403,{error:'허용되지 않은 요청 출처입니다.'});
 if(url.pathname==='/agent-connect'&&req.method==='GET'){
  const nonce=randomUUID();linkNonces.set(nonce,Date.now()+120000);for(const [key,expiry] of linkNonces)if(expiry<Date.now())linkNonces.delete(key);
  res.writeHead(200,{'Content-Type':'text/html;charset=utf-8','Cache-Control':'no-store','Content-Security-Policy':`default-src 'none'; script-src 'nonce-${nonce}'; connect-src 'self'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'`});
  return res.end(`<!doctype html><html lang="ko"><meta charset="utf-8"><title>Codex 실행기 연결</title><style>body{background:#211b28;color:#e4dce9;font:15px system-ui;padding:40px;line-height:1.9}h1{font-size:23px}</style><h1>이 컴퓨터의 Codex 연결</h1><p id="state">홈페이지 로그인과 Codex를 확인하고 있습니다.</p><p>기획 요청만 처리합니다. 이미지·영상 유료 생성 도구는 실행하지 않습니다. 로그인 정보는 메모리에만 보관합니다.</p><script nonce="${nonce}">
  const allowed=['https://www.socrabrand.cloud','https://socrabrand.cloud'];let used=false;
  window.addEventListener('message',async e=>{if(used||e.source!==window.opener||!allowed.includes(e.origin)||e.data?.type!=='kwan-studio:agent-session'||e.data.nonce!=='${nonce}')return;used=true;
  try{const r=await fetch('/api/cloud-link',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...e.data,nonce:'${nonce}'})});const d=await r.json();if(!r.ok)throw Error(d.error);document.getElementById('state').textContent='연결됐습니다. 홈페이지에서 요청한 기획을 이 컴퓨터의 Codex가 처리합니다. 연결은 현재 로그인 세션 동안 유효합니다.';window.opener.postMessage({type:'kwan-studio:agent-linked'},e.origin);}catch(error){document.getElementById('state').textContent=error.message;window.opener.postMessage({type:'kwan-studio:agent-error',error:error.message},e.origin);}});
  for(const origin of allowed)window.opener?.postMessage({type:'kwan-studio:agent-ready',nonce:'${nonce}'},origin);
  </script></html>`);
 }
 if(url.pathname==='/api/cloud-generation-requests'&&req.method==='GET'){try{return send(res,200,{requests:await cloudAgent.generationRequests()});}catch(e){return send(res,403,{error:e.message});}}
 const cloudResult=url.pathname.match(/^\/api\/cloud-generation-requests\/([a-f0-9-]{36})\/result$/);
 if(cloudResult&&req.method==='POST'){let body='';for await(const c of req){body+=c;if(Buffer.byteLength(body)>28e6)return send(res,413,{error:'20MB 이하 파일만 지원합니다.'});}try{return send(res,200,await cloudAgent.importResult(cloudResult[1],JSON.parse(body).media));}catch(e){return send(res,400,{error:e.message});}}
 if(url.pathname==='/api/cloud-link'&&req.method==='POST'){
  let body='';for await(const c of req){body+=c;if(Buffer.byteLength(body)>20000)return send(res,413,{error:'로그인 연결 크기를 확인하세요.'});}const data=JSON.parse(body);
  if(!linkNonces.has(data.nonce)||linkNonces.get(data.nonce)<Date.now())return send(res,403,{error:'연결 창이 만료됐습니다. 다시 열어 주세요.'});linkNonces.delete(data.nonce);
  try{return send(res,200,await cloudAgent.connect(data));}catch(e){return send(res,403,{error:e.message});}
 }
 if(url.pathname==='/api/codex/status'&&req.method==='GET'){try{return send(res,200,await codexStatus(root));}catch{return send(res,503,{connected:false,error:'Codex 연결을 확인하지 못했습니다. 설치와 로그인을 확인하세요.'});}}
 if(url.pathname==='/api/generation-requests'&&req.method==='GET')return send(res,200,{requests:(store.generationRequests||[]).map(({completedMediaPath,...r})=>({...r,instruction:requestInstruction(r)})),automaticDispatch:false,reason:'현재 데스크톱 채팅을 깨우는 연결은 설정되지 않았습니다.'});
 if(url.pathname==='/api/generation-requests'&&req.method==='POST'){let body='';for await(const c of req){body+=c;if(Buffer.byteLength(body)>100000)return send(res,413,{error:'요청 크기를 줄여 주세요.'});}const request=createGenerationRequest(JSON.parse(body),store.projects);const duplicate=(store.generationRequests||[]).find(r=>samePendingRequest(r,request));if(duplicate)return send(res,200,{request:duplicate,instruction:requestInstruction(duplicate),automaticDispatch:false,alreadyQueued:true});store.generationRequests=[...(store.generationRequests||[]),request].slice(-200);await persist();return send(res,201,{request,instruction:requestInstruction(request),automaticDispatch:false});}
 const cancelRequest=url.pathname.match(/^\/api\/generation-requests\/([a-f0-9-]{36})\/cancel$/);if(cancelRequest&&req.method==='POST'){const job=(store.generationRequests||[]).find(j=>j.id===cancelRequest[1]);if(!job)throw Error('요청이 없습니다.');if(job.status==='cancelled')return send(res,200,{cancelled:true,alreadyCancelled:true});if(job.status==='complete')return send(res,409,{error:'이미 보관된 결과는 취소할 수 없습니다.'});job.status='cancelled';job.message='취소된 요청';job.cancelledAt=new Date().toISOString();await persist();return send(res,200,{cancelled:true});}
 const resultMatch=url.pathname.match(/^\/api\/generation-requests\/([a-f0-9-]{36})\/result$/);if(resultMatch&&req.method==='POST'){let body='';for await(const c of req){body+=c;if(Buffer.byteLength(body)>28e6)return send(res,413,{error:'결과 파일은 20MB까지 지원합니다.'});}const data=JSON.parse(body);const job=(store.generationRequests||[]).find(r=>r.id===resultMatch[1]);if(!job)throw new Error('요청을 찾지 못했습니다.');if(job.status==='cancelled')return send(res,409,{error:'취소된 요청입니다. 새 요청으로 결과를 보관하세요.'});if(job.status==='complete')return send(res,200,{saved:true,alreadyCompleted:true,nodeId:job.resultNodeId});decodeMedia(data.media);if(!/^(image|video)\//.test(data.media.type))throw new Error('이미지·영상만 보관할 수 있습니다.');if(job.mediaKind&&!data.media.type.startsWith(job.mediaKind+'/'))throw new Error('요청한 이미지·영상 형식과 결과가 다릅니다.');const project=store.projects.find(p=>p.id===job.projectId);if(!project)throw new Error('프로젝트를 찾지 못했습니다.');let next,nodeId=job.nodeId;if(nodeId&&project.nodes.some(n=>n.id===nodeId)){next=mergeGenerationResult(project,job,data.media);}else{nodeId=randomUUID();next={...project,nodes:[...project.nodes,{id:nodeId,type:'studio',position:{x:100,y:Math.max(0,...project.nodes.map(n=>n.position.y))+500},data:{label:job.role?job.role+' 시안':job.modelName+' 결과',type:data.media.type.startsWith('image/')?'image':'video',tool:'upload',provider:job.provider||'magnific',model:job.model,mediaRole:'output',media:data.media,prompt:job.prompt,settings:{ratio:'원본',duration:5,resolution:'원본'},externalRequestId:job.id,resultRequestedAt:job.createdAt}}]};}const resultDir=path.join(dir,'generation-results');await mkdir(resultDir,{recursive:true});job.completedMediaPath=path.join(resultDir,job.id+'.json');await writeFile(job.completedMediaPath,JSON.stringify(data.media),{mode:0o600});job.status='complete';job.resultNodeId=nodeId;job.completedAt=new Date().toISOString();store.projects=store.projects.map(p=>p.id===next.id?next:p);await persist();return send(res,200,{saved:true,nodeId});}
 if(resultMatch&&req.method==='GET'){const job=(store.generationRequests||[]).find(r=>r.id===resultMatch[1]);if(!job?.completedMediaPath)return send(res,404,{error:'보관된 결과가 없습니다.'});const media=JSON.parse(await readFile(job.completedMediaPath,'utf8'));const project=store.projects.find(p=>p.id===job.projectId);const node=project?.nodes.find(n=>n.id===job.resultNodeId);return send(res,200,{media,node,requestId:job.id,request:{id:job.id,nodeId:job.nodeId,resultNodeId:job.resultNodeId,prompt:job.prompt,basis:job.basis,createdAt:job.createdAt}});}
 if(url.pathname==='/api/planning'&&req.method==='POST'){let body='';for await(const c of req){body+=c;if(Buffer.byteLength(body)>50000)return send(res,413,{error:'기획 요청 크기를 줄여 주세요.'});}const data=JSON.parse(body);const memories=(store.learning||[]).filter(m=>m.type==='approved').slice(-3);const projectId=data.projectId;if(!store.projects.some(p=>p.id===projectId))throw new Error('프로젝트를 먼저 저장하세요.');return send(res,202,await startPlanning(data.request,data.options||{},root,memories,async plan=>{const project=store.projects.find(p=>p.id===projectId);const finalPlan={...plan,visualBoard:{roles:{},notes:'',mode:'images'},revision:project.creativePlan?.revision||0,previousApprovals:[...(project.creativePlan?.previousApprovals||[]),...(project.creativePlan?.approval?[project.creativePlan.approval]:[])]};store.projects=store.projects.map(p=>p.id===projectId?{...p,creativePlan:finalPlan,updatedAt:new Date().toISOString()}:p);await persist();return finalPlan;}));}
 const planningCancel=url.pathname.match(/^\/api\/planning\/([a-f0-9-]{36})\/cancel$/);if(planningCancel&&req.method==='POST')return send(res,200,cancelPlanning(planningCancel[1]));
 const planningMatch=url.pathname.match(/^\/api\/planning\/([a-f0-9-]{36})$/);if(planningMatch&&req.method==='GET'){let job=getPlanningJob(planningMatch[1]);if(!job){try{job=JSON.parse(await readFile(path.join(dir,'planning',planningMatch[1],'job.json'),'utf8'));}catch{}}if(!job)return send(res,404,{error:'기획 작업을 찾지 못했습니다.'});const {processId,...safeJob}=job;return send(res,200,safeJob);}
 if(url.pathname==='/api/feedback'&&req.method==='POST'){let body='';for await(const c of req){body+=c;if(Buffer.byteLength(body)>20000)return send(res,413,{error:'피드백을 짧게 작성해 주세요.'});}const f=JSON.parse(body);if(store.projects.find(p=>p.id===f.projectId)?.isTestProject)return send(res,200,{saved:false,ignoredTestProject:true});if(!['approved','revision'].includes(f.type)||typeof f.summary!=='string'||f.summary.length>12000)throw new Error('피드백 형식을 확인하세요.');store.learning=[...(store.learning||[]),{type:f.type,summary:f.summary,at:new Date().toISOString()}].slice(-100);await persist();return send(res,200,{saved:true,count:store.learning.length});}
 if(url.pathname==='/api/render'&&req.method==='POST'){let body='';for await(const c of req){body+=c;if(Buffer.byteLength(body)>35e6)return send(res,413,{error:'요청 크기 35MB 제한'});}return send(res,202,startRender(JSON.parse(body),path.join(dir,'renders')));}
 const renderMatch=url.pathname.match(/^\/api\/render\/([a-f0-9-]{36})(\/file)?$/);
 if(renderMatch&&req.method==='GET'){if(renderMatch[2]){const bytes=await getRenderFile(renderMatch[1]);if(!bytes)return send(res,404,{error:'아직 출력 파일이 없습니다.'});res.writeHead(200,{'Content-Type':'video/mp4','Content-Disposition':'attachment; filename=kwan-film.mp4','Cache-Control':'no-store','Content-Length':bytes.length});return res.end(bytes);}const job=getRender(renderMatch[1]);return send(res,job?200:404,job||{error:'출력 작업을 찾지 못했습니다. 서버가 재시작되었을 수 있습니다.'});}
 if(url.pathname==='/api/workspace'&&req.method==='GET')return send(res,200,store);
 if(url.pathname==='/api/project'&&req.method==='POST'){
 let body='';for await(const c of req){body+=c;if(Buffer.byteLength(body)>35e6)return send(res,413,{error:'프로젝트가 35MB를 넘었습니다.'});}
 const p=validateProject(JSON.parse(body));if(typeof p.id!=='string'||typeof p.name!=='string')throw new Error('프로젝트 ID와 이름이 필요합니다.');
 const safe={id:p.id,name:p.name,isTestProject:p.isTestProject===true,nodes:p.nodes,edges:p.edges,scenes:normalizeScenes(p.scenes||[]),film:p.film&&typeof p.film==='object'?p.film:{},productionRuns:Array.isArray(p.productionRuns)?p.productionRuns:[],creativePlan:p.creativePlan&&typeof p.creativePlan==='object'?p.creativePlan:null,updatedAt:new Date().toISOString()};
 store.projects=[safe,...store.projects.filter(x=>x.id!==p.id)];await persist();return send(res,200,{saved:true,updatedAt:safe.updatedAt});
 }
 if(url.pathname.startsWith('/api/'))return send(res,404,{error:'요청한 기능은 아직 연결되지 않았습니다.'});
 const rel=decodeURIComponent(url.pathname).replace(/^\/+/,''),file=path.resolve(root,'dist',rel||'index.html');
 if(!file.startsWith(path.join(root,'dist')+path.sep))return send(res,403,{error:'잘못된 파일 경로'});
 const ext=path.extname(file);const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.woff2':'font/woff2'};
 let content;try{content=await readFile(file);}catch(e){if(ext)return send(res,404,{error:'파일 없음'});content=await readFile(path.join(root,'dist/index.html'));}
 res.writeHead(200,{'Content-Type':mime[ext]||'text/html','X-Content-Type-Options':'nosniff'});res.end(content);
 }catch(e){send(res,400,{error:e.message});}
});
server.listen(4318,'127.0.0.1',()=>console.log('Kwan Studio: http://127.0.0.1:4318'));
